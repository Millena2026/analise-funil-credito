import pandas as pd
import logging
from datetime import datetime
from pathlib import Path

logging.basicConfig(
    filename=f"logs/execucao_{datetime.now():%Y%m%d_%H%M%S}.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

COLUNAS_ESPERADAS = [
    "id_proposta", "data_entrada", "canal_origem", "cidade", "uf",
    "tipo_imovel", "valor_imovel", "valor_solicitado", "prazo_meses",
    "score_credito", "idade_cliente", "renda_mensal_declarada",
    "flag_cliente_recorrente", "consultor_id", "etapa_max_funil",
    "status_final", "tempo_analise_dias", "data_assinatura_contrato",
    "taxa_juros_aa"
]


def carregar_dados(caminho_csv):
    logging.info(f"Iniciando leitura de {caminho_csv}")

    if not Path(caminho_csv).exists():
        logging.error(f"Arquivo não encontrado: {caminho_csv}")
        raise FileNotFoundError(f"Arquivo não encontrado: {caminho_csv}")

    df = pd.read_csv(caminho_csv)
    logging.info(f"Arquivo lido: {df.shape[0]} linhas, {df.shape[1]} colunas")

    colunas_faltando = set(COLUNAS_ESPERADAS) - set(df.columns)
    if colunas_faltando:
        logging.error(f"Colunas faltando: {colunas_faltando}")
        raise ValueError(f"Colunas obrigatórias ausentes: {colunas_faltando}")

    return df


def tratar_dados(df):
    df = df.copy()
    logging.info("Iniciando tratamento de dados")
    
    df = df[df["tipo_imovel"] != "Terreno"].copy()

    df["valor_imovel"] = (
        df["valor_imovel"]
        .astype(str)
        .str.replace("R$", "", regex=False)
        .str.strip()
        .astype(float)
    )

    data_convertida = pd.to_datetime(df["data_entrada"], format="%Y-%m-%d", errors="coerce")
    ainda_vazio = data_convertida.isna()
    if ainda_vazio.any():
        data_convertida[ainda_vazio] = pd.to_datetime(
            df["data_entrada"][ainda_vazio], format="%d/%m/%Y", errors="coerce"
        )
    df["data_entrada"] = data_convertida
    n_datas_invalidas = df["data_entrada"].isna().sum()
    if n_datas_invalidas > 0:
        logging.warning(f"{n_datas_invalidas} datas não convertidas")

    df["canal_origem"] = df["canal_origem"].str.strip().str.capitalize()

    invalidos = ~df["etapa_max_funil"].between(1, 6)
    if invalidos.any():
        logging.warning(f"{invalidos.sum()} registros com etapa_max_funil fora de 1-6")
        mascara_corrigivel = invalidos & (df["status_final"] == "Contratada")
        df.loc[mascara_corrigivel, "etapa_max_funil"] = 6

    df["ltv"] = df["valor_solicitado"] / df["valor_imovel"]

    logging.info("Tratamento de dados concluído")
    return df


def calcular_metricas(df):
    logging.info("Calculando métricas do funil")

    perdidas = df[df["status_final"] != "Contratada"]

    perda_por_etapa = perdidas.groupby("etapa_max_funil").agg(
        propostas_perdidas=("id_proposta", "count"),
        valor_perdido=("valor_solicitado", "sum")
    ).reset_index()

    conversao_por_canal = df.groupby("canal_origem")["status_final"].apply(
        lambda x: (x == "Contratada").mean()
    ).sort_values(ascending=False).reset_index(name="taxa_conversao")

    total_propostas = len(df)
    total_contratadas = (df["status_final"] == "Contratada").sum()
    taxa_conversao_geral = total_contratadas / total_propostas

    violacoes_ltv = df[df["ltv"] > 0.60]
    n_violacoes_ltv = len(violacoes_ltv)
    n_violacoes_contratadas = (violacoes_ltv["status_final"] == "Contratada").sum()

    metricas = {
        "data_geracao": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "total_propostas": total_propostas,
        "total_contratadas": total_contratadas,
        "taxa_conversao_geral": taxa_conversao_geral,
        "perda_por_etapa": perda_por_etapa,
        "conversao_por_canal": conversao_por_canal,
        "n_violacoes_ltv": n_violacoes_ltv,
        "n_violacoes_ltv_contratadas": n_violacoes_contratadas,
    }

    logging.info("Métricas calculadas com sucesso")
    return metricas


def gerar_html(metricas, caminho_saida):
    logging.info(f"Gerando relatório HTML em {caminho_saida}")

    perda_df = metricas["perda_por_etapa"]
    max_valor = perda_df["valor_perdido"].max()
    nomes_etapas = {
        1: "Simulação", 2: "Lead", 3: "Análise de crédito",
        4: "Avaliação do imóvel", 5: "Formalização"
    }

    barras_etapa = ""
    for row in perda_df.itertuples():
        largura = (row.valor_perdido / max_valor) * 100
        nome = nomes_etapas.get(row.etapa_max_funil, f"Etapa {row.etapa_max_funil}")
        barras_etapa += f"""
        <div class="linha-barra">
            <div class="rotulo-barra">
                <span>{nome}</span>
                <span>R$ {row.valor_perdido:,.0f} &middot; {row.propostas_perdidas} propostas</span>
            </div>
            <div class="trilha-barra">
                <div class="preenchimento-barra" style="width:{largura:.1f}%"></div>
            </div>
        </div>
        """

    canal_pior = metricas["conversao_por_canal"].iloc[-1]
    linhas_canal = ""
    for row in metricas["conversao_por_canal"].itertuples():
        destaque = "linha-alerta" if row.canal_origem == canal_pior.canal_origem else ""
        linhas_canal += f"""
        <tr class="{destaque}">
            <td>{row.canal_origem}</td>
            <td>{row.taxa_conversao:.1%}</td>
        </tr>
        """

    html = f"""
    <html>
    <head>
        <meta charset="utf-8">
        <title>Funil de Crédito &middot; Bari</title>
        <style>
            * {{ box-sizing: border-box; }}
            body {{
                font-family: Georgia, 'Times New Roman', serif;
                background: #F6F5F1;
                color: #1A1A1A;
                margin: 0;
                padding: 0 0 60px 0;
            }}
            .faixa-topo {{
                background: #14213D;
                color: #F6F5F1;
                padding: 36px 48px;
            }}
            .faixa-topo h1 {{
                margin: 0;
                font-size: 30px;
                font-weight: normal;
                letter-spacing: 0.5px;
            }}
            .faixa-topo p {{
                margin: 6px 0 0 0;
                font-family: Arial, sans-serif;
                font-size: 13px;
                color: #A9B4C9;
                text-transform: uppercase;
                letter-spacing: 1.5px;
            }}
            .conteudo {{ max-width: 880px; margin: 0 auto; padding: 0 48px; }}
            .cards {{
                display: flex;
                gap: 16px;
                margin-top: -28px;
            }}
            .card {{
                background: white;
                border-radius: 4px;
                border-top: 3px solid #C4622D;
                padding: 18px 22px;
                flex: 1;
                box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            }}
            .card .rotulo {{
                font-family: Arial, sans-serif;
                font-size: 11px;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: #777;
            }}
            .card .numero {{
                font-size: 30px;
                margin-top: 4px;
                color: #14213D;
            }}
            h2 {{
                font-weight: normal;
                font-size: 20px;
                border-bottom: 2px solid #C4622D;
                display: inline-block;
                padding-bottom: 4px;
                margin-top: 46px;
            }}
            .linha-barra {{ margin: 18px 0; }}
            .rotulo-barra {{
                display: flex;
                justify-content: space-between;
                font-family: Arial, sans-serif;
                font-size: 13px;
                margin-bottom: 4px;
                color: #333;
            }}
            .trilha-barra {{
                background: #E4E1D8;
                border-radius: 3px;
                height: 14px;
                overflow: hidden;
            }}
            .preenchimento-barra {{
                background: #C4622D;
                height: 100%;
            }}
            table {{ border-collapse: collapse; width: 100%; margin-top: 16px; font-family: Arial, sans-serif; font-size: 14px; }}
            th {{ text-align: left; padding: 10px 12px; border-bottom: 2px solid #14213D; color: #14213D; }}
            td {{ padding: 10px 12px; border-bottom: 1px solid #E4E1D8; }}
            .linha-alerta td {{ color: #A32D2D; font-weight: bold; }}
            .caixa-alerta {{
                background: #FBEAE5;
                border-left: 4px solid #A32D2D;
                padding: 16px 20px;
                margin-top: 20px;
                font-family: Arial, sans-serif;
                font-size: 14px;
                color: #5A1F1F;
            }}
            .rodape {{
                margin-top: 50px;
                font-family: Arial, sans-serif;
                font-size: 11px;
                color: #999;
                text-align: center;
            }}
        </style>
    </head>
    <body>
        <div class="faixa-topo">
            <p>Bari &middot; Crédito com garantia de imóvel</p>
            <h1>Relatório semanal do funil de propostas</h1>
        </div>

        <div class="conteudo">
            <div class="cards">
                <div class="card">
                    <div class="rotulo">Propostas no período</div>
                    <div class="numero">{metricas['total_propostas']:,}</div>
                </div>
                <div class="card">
                    <div class="rotulo">Contratadas</div>
                    <div class="numero">{metricas['total_contratadas']:,}</div>
                </div>
                <div class="card">
                    <div class="rotulo">Conversão geral</div>
                    <div class="numero">{metricas['taxa_conversao_geral']:.1%}</div>
                </div>
            </div>

            <h2>Onde o funil perde valor</h2>
            {barras_etapa}

            <h2>Conversão por canal de origem</h2>
            <table>
                <tr><th>Canal</th><th>Taxa de conversão</th></tr>
                {linhas_canal}
            </table>

            <h2>Política de crédito</h2>
            <div class="caixa-alerta">
                {metricas['n_violacoes_ltv']} propostas ultrapassam o LTV máximo de 60% definido na política,
                das quais <strong>{metricas['n_violacoes_ltv_contratadas']} já foram contratadas</strong>
                &mdash; recomenda-se auditoria desses casos.
            </div>

            <div class="rodape">Gerado automaticamente em {metricas['data_geracao']}</div>
        </div>
    </body>
    </html>
    """

    Path(caminho_saida).write_text(html, encoding="utf-8")
    logging.info("Relatório HTML gerado com sucesso")


def main():
    try:
        df = carregar_dados("dados/propostas_credito.csv")
        df = tratar_dados(df)
        metricas = calcular_metricas(df)

        nome_arquivo = f"saida/relatorio_funil_{datetime.now():%Y%m%d_%H%M%S}.html"
        gerar_html(metricas, nome_arquivo)

        print(f"Relatório gerado com sucesso: {nome_arquivo}")

    except Exception as e:
        logging.error(f"Falha na execução do script: {e}")
        print(f"Erro ao gerar relatório: {e}")


if __name__ == "__main__":
    main()