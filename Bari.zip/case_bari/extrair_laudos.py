import re
import json
import csv
from pathlib import Path

MESES = {
    "janeiro": "01", "fevereiro": "02", "março": "03", "abril": "04",
    "maio": "05", "junho": "06", "julho": "07", "agosto": "08",
    "setembro": "09", "outubro": "10", "novembro": "11", "dezembro": "12"
}

PALAVRAS_TIPO_IMOVEL = [
    ("apartamento", "apartamento"),
    ("sala comercial", "sala comercial"),
    ("loja", "loja"),
    ("galpão", "galpão industrial"),
    ("terreno", "terreno"),
    ("sítio", "imóvel rural"),
    ("rural", "imóvel rural"),
    ("casa", "casa"),
    ("unidade comercial", "sala comercial"),
]


def extrair_tipo_imovel(texto):
    texto_lower = texto.lower()
    candidatos = []
    for chave, valor in PALAVRAS_TIPO_IMOVEL:
        pos = texto_lower.find(chave)
        if pos != -1:
            candidatos.append((pos, valor))
    if not candidatos:
        return None
    candidatos.sort(key=lambda x: x[0])
    return candidatos[0][1]


def extrair_endereco(texto):
    padroes = [
        r"Endere[cç]o(?:\s+do\s+im[oó]vel)?:\s*([^\n]+)",
        r"Local(?:iza[cç][aã]o)?(?:\s+do\s+bem)?:\s*([^\n]+)",
    ]
    for p in padroes:
        m = re.search(p, texto, re.IGNORECASE)
        if m:
            return m.group(1).strip().rstrip(".")

    m = re.search(
        r"((?:Rua|Av\.?|Avenida|Alameda|Rodovia|Lote|SQN)[^\n\.]+(?:/[A-Z]{2}|-\s*[A-Z]{2}))",
        texto
    )
    if m:
        return m.group(1).strip()

    m2 = re.search(r"Munic[ií]pio\s+de\s+([^\n\.]+)", texto, re.IGNORECASE)
    if m2:
        return m2.group(1).strip()
    return None


def extrair_areas(texto):
    areas = []
    padrao = re.compile(
        r"[aá]rea\s+(?:do\s+)?(privativa|[uú]til|constru[ií]da|edificada|coberta|"
        r"comum\s+proporcional|terreno|total|do\s+lote|do\s+terreno)?[,:\s]*"
        r"(?:aproximada[,:\s]*)?(?:de\s+)?([\d\.,]+)\s*(m[²2]|ha)",
        re.IGNORECASE
    )
    for m in padrao.finditer(texto):
        categoria = (m.group(1) or "não especificada").lower().strip()
        unidade = "ha" if m.group(3).lower() == "ha" else "m²"
        areas.append({
            "categoria": categoria,
            "valor": m.group(2),
            "unidade": unidade,
            "evidencia": m.group(0)
        })

    padrao_inverso = re.compile(
        r"([\d\.,]+)\s*(m[²2]|ha)\s+de\s+[aá]rea\s+"
        r"(privativa|[uú]til|constru[ií]da|edificada|coberta|total)",
        re.IGNORECASE
    )
    for m in padrao_inverso.finditer(texto):
        areas.append({
            "categoria": m.group(3).lower(),
            "valor": m.group(1),
            "unidade": "ha" if m.group(2).lower() == "ha" else "m²",
            "evidencia": m.group(0)
        })

    m_lote = re.search(r"\blote\s+de\s+([\d\.,]+)\s*(m[²2]|ha)", texto, re.IGNORECASE)
    if m_lote:
        areas.append({
            "categoria": "lote",
            "valor": m_lote.group(1),
            "unidade": "ha" if m_lote.group(2).lower() == "ha" else "m²",
            "evidencia": m_lote.group(0)
        })

    for m in re.finditer(r"\bterreno(?:\s+com|\s+de)?[:\s]+([\d\.,]+)\s*(m[²2]|ha)", texto, re.IGNORECASE):
        ja_existe = any(
            a["categoria"] in ("terreno", "do terreno", "lote", "do lote") and a.get("valor") == m.group(1)
            for a in areas
        )
        if not ja_existe:
            areas.append({
                "categoria": "terreno",
                "valor": m.group(1),
                "unidade": "ha" if m.group(2).lower() == "ha" else "m²",
                "evidencia": m.group(0)
            })

    m_benf = re.search(r"benfeitorias\s+constru[ií]das:\s*([\d\.,]+)\s*(m[²2]|ha)", texto, re.IGNORECASE)
    if m_benf:
        areas.append({
            "categoria": "construída",
            "valor": m_benf.group(1),
            "unidade": "ha" if m_benf.group(2).lower() == "ha" else "m²",
            "evidencia": m_benf.group(0)
        })

    m2 = re.search(r"[Ss]uperf[ií]cie:\s*([\d\.,]+)\s*(m[²2]|ha)", texto)
    if m2:
        areas.append({
            "categoria": "terreno",
            "valor": m2.group(1),
            "unidade": "ha" if m2.group(2).lower() == "ha" else "m²",
            "evidencia": m2.group(0)
        })

    m_diverg = re.search(
        r"cabe[cç]alho\s+consta\s+[aá]rea\s+(\w+)\s+([\d\.,]+)\s*m[²2].{0,60}?"
        r"tabela\s+interna\s+registra\s+([\d\.,]+)",
        texto, re.IGNORECASE
    )
    if m_diverg:
        categoria_div = m_diverg.group(1).lower()
        areas = [a for a in areas if a["categoria"] != categoria_div]
        areas.append({
            "categoria": categoria_div,
            "estado": "divergente",
            "valores": [
                {"valor": m_diverg.group(2), "origem": "cabeçalho"},
                {"valor": m_diverg.group(3), "origem": "tabela interna"},
            ],
            "unidade": "m²",
            "evidencia": m_diverg.group(0)
        })

    return areas


def extrair_ano_construcao(texto):
    if re.search(r"ano.{0,20}(n[aã]o se aplica|inexistente)", texto, re.IGNORECASE):
        return {"estado": "não se aplica", "valor": None}

    padroes = [
        r"[Aa]no\s+de\s+constru[cç][aã]o(?:\s+informado[a]?\s+pel[oa]\s+propriet[aá]rio)?:\s*(\d{4})",
        r"[Cc]onstru[ií]d[oa]\s+em\s+(\d{4})",
        r"[Cc]onstru[cç][aã]o:\s*(\d{4})",
        r"[Aa]no\s+informado:\s*(\d{4})",
        r"[Aa]no\s+das\s+edifica[cç][oõ]es:\s*(\d{4})",
        r"[Aa]no\s+de\s+refer[eê]ncia:\s*(\d{4})",
        r"[Aa]no\s+de\s+conclus[aã]o\s*(\d{4})",
        r"\b[Aa]no\s*(\d{4})\b",
        r"com\s+(\d{4})\s+de\s+constru[cç][aã]o",
    ]
    for p in padroes:
        m = re.search(p, texto)
        if m:
            return {"estado": "informado", "valor": int(m.group(1))}

    m_idade = re.search(r"[Ii]dade(?:\s+aparente)?:?\s*(?:aproximadamente\s*)?(\d+)\s*anos", texto)
    if m_idade:
        return {"estado": "aproximado_por_idade", "valor": None, "idade_anos": int(m_idade.group(1))}

    return {"estado": "não informado", "valor": None}


def extrair_valor_avaliacao(texto):
    m = re.search(r"R\$\s*([\d\.]+(?:,\d{2})?)", texto)
    if not m:
        return None
    limpo = m.group(1).replace(".", "").replace(",", ".")
    try:
        return float(limpo)
    except ValueError:
        return None


def extrair_matricula(texto):
    m = re.search(r"[Mm]atr[ií]cula:?\s*(?:n[ºo]\.?\s*)?(\d[\d\.]*\d|\d)", texto)
    if m:
        return m.group(1), "matrícula"
    m = re.search(r"[Rr]egistro\s+imobili[aá]rio\s+n[ºo]\.?\s*(\d[\d\.]*\d|\d)", texto)
    if m:
        return m.group(1), "registro imobiliário (assumido como matrícula)"
    return None, None


def extrair_onus(texto):
    m = re.search(
        r"([^\n]*(?:[oÔÕ]nus|penhora|hipoteca|gravame|aliena[cç][aã]o fiduci[aá]ria|servid[aã]o)[^\n]*\.)",
        texto, re.IGNORECASE
    )
    if m:
        return m.group(1).strip()
    return None


def extrair_data_vistoria(texto):
    m = re.search(r"(\d{2})[/-](\d{2})[/-](\d{4})", texto)
    if m:
        dia, mes, ano = m.groups()
        return f"{ano}-{mes}-{dia}"

    m2 = re.search(r"(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})", texto, re.IGNORECASE)
    if m2:
        dia, mes_nome, ano = m2.groups()
        mes = MESES.get(mes_nome.lower())
        if mes:
            return f"{ano}-{mes}-{dia.zfill(2)}"
    return None


def extrair_responsavel(texto):
    padroes = [
        r"Respons[aá]vel(?:\s+t[eé]cnico)?(?:\s+pelo\s+trabalho)?:\s*([^\n]+)",
        r"RT:\s*([^\n]+)",
        r"Avaliador[a]?(?:\s+respons[aá]vel)?:\s*([^\n]+)",
        r"Perito\s+avaliador:\s*([^\n]+)",
        r"Perita:\s*([^\n]+)",
        r"Elaborado\s+por:\s*([^\n]+)",
    ]
    for p in padroes:
        m = re.search(p, texto, re.IGNORECASE)
        if m:
            return m.group(1).strip().rstrip(".")
    return None


def extrair_campos(texto, nome_arquivo):
    matricula, matricula_termo = extrair_matricula(texto)
    return {
        "arquivo": nome_arquivo,
        "tipo_imovel": extrair_tipo_imovel(texto),
        "endereco": extrair_endereco(texto),
        "areas": extrair_areas(texto),
        "ano_construcao": extrair_ano_construcao(texto),
        "valor_avaliacao": extrair_valor_avaliacao(texto),
        "matricula": matricula,
        "matricula_termo_original": matricula_termo,
        "onus": extrair_onus(texto),
        "data_vistoria": extrair_data_vistoria(texto),
        "responsavel_tecnico": extrair_responsavel(texto),
    }


def resumir_area(areas, categorias):
    encontradas = [a for a in areas if a["categoria"] in categorias]
    if not encontradas:
        return ""
    a = encontradas[0]
    if a.get("estado") == "divergente":
        valores = " vs ".join(f"{v['valor']} ({v['origem']})" for v in a["valores"])
        return f"DIVERGENTE: {valores}"
    return f"{a['valor']} {a['unidade']}"


def main():
    resultados = []
    pasta_laudos = Path("dados/laudos_avaliacao")
    for arquivo in sorted(pasta_laudos.glob("*.txt")):
        texto = arquivo.read_text(encoding="utf-8")
        resultados.append(extrair_campos(texto, arquivo.name))

    Path("saida").mkdir(exist_ok=True)

    with open("saida/laudos_extraidos.json", "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2)

    with open("saida/laudos_extraidos.csv", "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow([
            "arquivo", "tipo_imovel", "endereco", "area_privativa_ou_util", "area_total",
            "area_construida", "area_terreno_ou_lote", "ano_construcao", "valor_avaliacao",
            "matricula", "termo_da_matricula", "onus", "data_vistoria", "responsavel_tecnico"
        ])
        for r in resultados:
            ano = r["ano_construcao"]
            ano_str = ano["valor"] if ano["estado"] == "informado" else ano["estado"]
            writer.writerow([
                r["arquivo"], r["tipo_imovel"] or "não informado",
                r["endereco"] or "não informado",
                resumir_area(r["areas"], ["privativa", "útil", "util"]) or "não informado",
                resumir_area(r["areas"], ["total"]) or "não informado",
                resumir_area(r["areas"], ["construída", "construida", "edificada", "coberta"]) or "não informado",
                resumir_area(r["areas"], ["terreno", "do terreno", "lote", "do lote"]) or "não informado",
                ano_str, r["valor_avaliacao"],
                r["matricula"] or "não informado",
                r["matricula_termo_original"] or "",
                r["onus"] or "não informado", r["data_vistoria"] or "não informado",
                r["responsavel_tecnico"] or "não informado"
            ])

    print(f"Extração concluída: {len(resultados)} laudos processados.")
    print("Arquivos gerados: saida/laudos_extraidos.json e saida/laudos_extraidos.csv")


if __name__ == "__main__":
    main()