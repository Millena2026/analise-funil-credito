Diário de Bordo

1. Uso de Inteligência Artificial

Usei IA principalmente para me ajudar na programação, pois ainda estou aprendendo Python e não tenho todos os comandos memorizados.

Usei para entender erros, tirar dúvidas, revisar código e encontrar soluções. Sempre testei as sugestões antes de usar.

Em um momento, pedi uma solução para a IA e ela trouxe muitas coisas desnecessárias para o que eu precisava. Tive que analisar o que realmente era relevante e pedir uma versão mais curta e simples. Isso me mostrou que usar IA não significa aceitar tudo que ela entrega.

Também tive problemas na extração dos laudos, porque cada arquivo tinha um formato diferente. Algumas regras não funcionaram em todos os casos, então precisei testar e ajustar.

2. O que aprendi

Aprendi a usar Regex (expressões regulares) para procurar informações em textos, como datas, valores e áreas.

Aprendi com a documentação do Python e com testes durante o projeto. Levei aproximadamente 1h30 para entender o básico e aplicar no código.

3. Autocrítica

A extração dos laudos ainda pode melhorar, principalmente para documentos com formatos diferentes.

Também poderia aprofundar mais a análise do funil e criar mais testes.

Com mais 40 horas, eu melhoraria o extrator, faria mais testes e aprofundaria a análise das perdas.

4. Pergunta que eu faria ao negócio

Eu gostaria de ter perguntado:

“Qual é a principal decisão que a liderança precisa tomar com essa análise?”

Isso ajudaria a focar ainda mais o projeto no que realmente importa para o negócio.

5 Tempo

Aproximadamente 3 dias, com 4 horas por dia, totalizando cerca de 12 horas.