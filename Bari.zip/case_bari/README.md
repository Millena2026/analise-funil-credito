Análise de Funil de Crédito

Projeto desenvolvido para o desafio prático de Estágio AI & Data Lab | Bari.

O objetivo foi analisar o funil de propostas, automatizar um relatório semanal e extrair informações dos 17 laudos de avaliação.

Parte 1 — Análise do funil

Arquivo: exploracao.ipynb

A base tinha 6.400 propostas. Foram retirados os imóveis do tipo Terreno, ficando 5.865 propostas.

Foram analisados conversão, perda de valor, canais, características das propostas, LTV e tratamento dos dados.

Foram 1.128 propostas contratadas, com conversão de 19,2%. A maior perda de valor aconteceu na etapa 3, Análise de crédito, com aproximadamente R$ 649,8 milhões.

Parte 2 — Automação

Arquivo: relatorio_semanal.py

O programa lê a base, trata os dados, remove Terreno, calcula as métricas e gera um relatório HTML e um log.

Para executar: python relatorio_semanal.py

Parte 3 — Laudos

Arquivo: extrair_laudos.py

O programa extrai informações dos 17 laudos, como tipo de imóvel, endereço, áreas, ano, valor, matrícula, ônus, data da vistoria e responsável técnico.

Nos testes, foram avaliados 153 campos: 140 corretos, 8 parcialmente corretos e 5 errados ou não identificados.

Para executar: python extrair_laudos.py

Uso de IA

Usei IA principalmente para me ajudar com Python, entender erros, tirar dúvidas e revisar o código.

Em alguns momentos, a IA trouxe soluções maiores do que eu precisava. Então precisei analisar o que fazia sentido e pedir versões mais simples.

Na extração dos laudos, também precisei ajustar algumas regras porque os documentos tinham formatos diferentes.

Um detalhe inesperado pode atrapalhar uma regra de extração — até um abacaxi no meio de um texto.

Limitações

O extrator foi testado somente com os 17 laudos fornecidos.

A análise mostra relações entre os dados, mas não prova que uma característica seja a causa da contratação.

Tempo

Aproximadamente 3 dias, com 4 horas por dia, totalizando cerca de 12 horas.